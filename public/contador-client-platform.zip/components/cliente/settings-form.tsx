"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

type User = {
  id: string
  name: string
  email: string
}

export function ClienteSettingsForm({ user }: { user: User }) {
  const router = useRouter()
  const supabase = createClient()
  const [name, setName] = useState(user.name)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSave = async () => {
    setIsSubmitting(true)
    setSuccess(false)

    const { error } = await supabase
      .from("users")
      .update({ name })
      .eq("id", user.id)

    if (!error) {
      setSuccess(true)
      router.refresh()
    }
    setIsSubmitting(false)
  }

  return (
    <div className="max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle>Informacoes Pessoais</CardTitle>
          <CardDescription>Atualize suas informacoes de conta</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="name">Nome</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              value={user.email}
              disabled
              className="bg-muted"
            />
            <p className="text-xs text-muted-foreground">
              O email nao pode ser alterado
            </p>
          </div>
          <div className="flex items-center gap-4 pt-4">
            <Button onClick={handleSave} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                "Salvar alteracoes"
              )}
            </Button>
            {success && (
              <span className="text-sm text-green-600">Alteracoes salvas com sucesso!</span>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
