"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import useSWR from "swr"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  ArrowLeft,
  User,
  Mail,
  Phone,
  Building,
  FileText,
  Plus,
  StickyNote,
  Trash2,
  Download,
  Upload,
  Loader2,
  Calendar,
} from "lucide-react"

type Client = {
  id: string
  name: string
  email: string
  phone: string | null
  company: string | null
  document_number: string | null
  created_at: string
}

type Document = {
  id: string
  name: string
  file_url: string
  file_type: string
  category: string
  created_at: string
}

type Note = {
  id: string
  content: string
  created_at: string
}

export function ClientProfile({ client, contadorId }: { client: Client; contadorId: string }) {
  const router = useRouter()
  const supabase = createClient()
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false)
  const [isUploadOpen, setIsUploadOpen] = useState(false)
  const [editClient, setEditClient] = useState(client)
  const [newNote, setNewNote] = useState("")
  const [uploadFile, setUploadFile] = useState<File | null>(null)
  const [uploadCategory, setUploadCategory] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const { data: documents, mutate: mutateDocuments } = useSWR<Document[]>(
    ["documents", client.id],
    async () => {
      const { data, error } = await supabase
        .from("documents")
        .select("*")
        .eq("client_id", client.id)
        .order("created_at", { ascending: false })
      if (error) throw error
      return data
    }
  )

  const { data: notes, mutate: mutateNotes } = useSWR<Note[]>(
    ["notes", client.id],
    async () => {
      const { data, error } = await supabase
        .from("notes")
        .select("*")
        .eq("client_id", client.id)
        .order("created_at", { ascending: false })
      if (error) throw error
      return data
    }
  )

  const handleUpdateClient = async () => {
    setIsSubmitting(true)
    const { error } = await supabase
      .from("clients")
      .update({
        name: editClient.name,
        email: editClient.email,
        phone: editClient.phone,
        company: editClient.company,
        document_number: editClient.document_number,
      })
      .eq("id", client.id)

    if (!error) {
      setIsEditDialogOpen(false)
      router.refresh()
    }
    setIsSubmitting(false)
  }

  const handleAddNote = async () => {
    if (!newNote.trim()) return
    setIsSubmitting(true)
    const { error } = await supabase.from("notes").insert({
      client_id: client.id,
      contador_id: contadorId,
      content: newNote,
    })

    if (!error) {
      setNewNote("")
      setIsAddNoteOpen(false)
      mutateNotes()
    }
    setIsSubmitting(false)
  }

  const handleDeleteNote = async (noteId: string) => {
    const { error } = await supabase.from("notes").delete().eq("id", noteId)
    if (!error) {
      mutateNotes()
    }
  }

  const handleUploadDocument = async () => {
    if (!uploadFile || !uploadCategory) return
    setIsSubmitting(true)

    const fileExt = uploadFile.name.split(".").pop()
    const fileName = `${client.id}/${Date.now()}.${fileExt}`

    const { error: uploadError } = await supabase.storage
      .from("documents")
      .upload(fileName, uploadFile)

    if (uploadError) {
      setIsSubmitting(false)
      return
    }

    const { data: { publicUrl } } = supabase.storage
      .from("documents")
      .getPublicUrl(fileName)

    const { error } = await supabase.from("documents").insert({
      client_id: client.id,
      contador_id: contadorId,
      name: uploadFile.name,
      file_url: publicUrl,
      file_type: uploadFile.type,
      category: uploadCategory,
    })

    if (!error) {
      setUploadFile(null)
      setUploadCategory("")
      setIsUploadOpen(false)
      mutateDocuments()
    }
    setIsSubmitting(false)
  }

  const handleDeleteDocument = async (docId: string) => {
    const { error } = await supabase.from("documents").delete().eq("id", docId)
    if (!error) {
      mutateDocuments()
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  return (
    <div className="p-8">
      <div className="mb-6">
        <Button variant="ghost" asChild className="mb-4">
          <Link href="/contador">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Link>
        </Button>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center justify-center w-16 h-16 rounded-xl bg-secondary text-secondary-foreground">
              <User className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">{client.name}</h1>
              <p className="text-muted-foreground">{client.company || "Cliente individual"}</p>
            </div>
          </div>
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">Editar</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Editar Cliente</DialogTitle>
                <DialogDescription>Atualize os dados do cliente</DialogDescription>
              </DialogHeader>
              <div className="flex flex-col gap-4 py-4">
                <div className="flex flex-col gap-2">
                  <Label>Nome</Label>
                  <Input
                    value={editClient.name}
                    onChange={(e) => setEditClient({ ...editClient, name: e.target.value })}
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={editClient.email}
                    onChange={(e) => setEditClient({ ...editClient, email: e.target.value })}
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label>Telefone</Label>
                  <Input
                    value={editClient.phone || ""}
                    onChange={(e) => setEditClient({ ...editClient, phone: e.target.value })}
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label>Empresa</Label>
                  <Input
                    value={editClient.company || ""}
                    onChange={(e) => setEditClient({ ...editClient, company: e.target.value })}
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label>CPF/CNPJ</Label>
                  <Input
                    value={editClient.document_number || ""}
                    onChange={(e) => setEditClient({ ...editClient, document_number: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleUpdateClient} disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Salvar"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-medium text-foreground">{client.email}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Telefone</p>
                <p className="font-medium text-foreground">{client.phone || "-"}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Building className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">CPF/CNPJ</p>
                <p className="font-medium text-foreground">{client.document_number || "-"}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Cliente desde</p>
                <p className="font-medium text-foreground">{formatDate(client.created_at)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="documents" className="w-full">
        <TabsList>
          <TabsTrigger value="documents" className="gap-2">
            <FileText className="w-4 h-4" />
            Documentos
          </TabsTrigger>
          <TabsTrigger value="notes" className="gap-2">
            <StickyNote className="w-4 h-4" />
            Notas Internas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Documentos</CardTitle>
                <CardDescription>Documentos do cliente</CardDescription>
              </div>
              <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Upload className="w-4 h-4 mr-2" />
                    Enviar Documento
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Enviar Documento</DialogTitle>
                    <DialogDescription>Faca upload de um documento para o cliente</DialogDescription>
                  </DialogHeader>
                  <div className="flex flex-col gap-4 py-4">
                    <div className="flex flex-col gap-2">
                      <Label>Categoria</Label>
                      <Input
                        value={uploadCategory}
                        onChange={(e) => setUploadCategory(e.target.value)}
                        placeholder="Ex: Declaracao IR, Balanco, etc."
                      />
                    </div>
                    <div className="flex flex-col gap-2">
                      <Label>Arquivo</Label>
                      <Input
                        type="file"
                        onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsUploadOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleUploadDocument} disabled={!uploadFile || !uploadCategory || isSubmitting}>
                      {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Enviar"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {!documents ? (
                <div className="py-8 text-center">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto text-muted-foreground" />
                </div>
              ) : documents.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground">
                  Nenhum documento enviado
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center justify-between p-4 rounded-lg border bg-secondary/30"
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-primary" />
                        <div>
                          <p className="font-medium text-foreground">{doc.name}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary">{doc.category}</Badge>
                            <span className="text-xs text-muted-foreground">
                              {formatDate(doc.created_at)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                            <Download className="w-4 h-4" />
                          </a>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteDocument(doc.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notes" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Notas Internas</CardTitle>
                <CardDescription>Notas visiveis apenas para voce</CardDescription>
              </div>
              <Dialog open={isAddNoteOpen} onOpenChange={setIsAddNoteOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Nova Nota
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Nova Nota</DialogTitle>
                    <DialogDescription>Adicione uma nota interna sobre este cliente</DialogDescription>
                  </DialogHeader>
                  <div className="py-4">
                    <Textarea
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      placeholder="Digite sua nota..."
                      rows={4}
                    />
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddNoteOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleAddNote} disabled={!newNote.trim() || isSubmitting}>
                      {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Salvar"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {!notes ? (
                <div className="py-8 text-center">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto text-muted-foreground" />
                </div>
              ) : notes.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground">
                  Nenhuma nota adicionada
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {notes.map((note) => (
                    <div
                      key={note.id}
                      className="p-4 rounded-lg border bg-secondary/30"
                    >
                      <div className="flex items-start justify-between">
                        <p className="text-foreground whitespace-pre-wrap">{note.content}</p>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteNote(note.id)}
                          className="text-muted-foreground hover:text-destructive shrink-0 ml-4"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {formatDate(note.created_at)}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
