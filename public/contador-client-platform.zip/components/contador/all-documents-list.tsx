"use client"

import { useState } from "react"
import Link from "next/link"
import useSWR from "swr"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, FileText, Download, Loader2, User } from "lucide-react"

type DocumentWithClient = {
  id: string
  name: string
  file_url: string
  file_type: string
  category: string
  created_at: string
  clients: {
    id: string
    name: string
    company: string | null
  }
}

export function AllDocumentsList({ contadorId }: { contadorId: string }) {
  const [search, setSearch] = useState("")
  const supabase = createClient()

  const { data: documents, error } = useSWR<DocumentWithClient[]>(
    ["all-documents", contadorId],
    async () => {
      const { data, error } = await supabase
        .from("documents")
        .select(`
          *,
          clients (
            id,
            name,
            company
          )
        `)
        .eq("contador_id", contadorId)
        .order("created_at", { ascending: false })

      if (error) throw error
      return data
    }
  )

  const filteredDocuments = documents?.filter(
    (doc) =>
      doc.name.toLowerCase().includes(search.toLowerCase()) ||
      doc.category.toLowerCase().includes(search.toLowerCase()) ||
      doc.clients?.name?.toLowerCase().includes(search.toLowerCase())
  )

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  if (error) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        Erro ao carregar documentos
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Buscar documentos..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      <div className="border rounded-lg bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Documento</TableHead>
              <TableHead>Cliente</TableHead>
              <TableHead>Categoria</TableHead>
              <TableHead>Data</TableHead>
              <TableHead className="w-[80px]">Acao</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {!documents ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-12">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto text-muted-foreground" />
                </TableCell>
              </TableRow>
            ) : filteredDocuments?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-12 text-muted-foreground">
                  {search ? "Nenhum documento encontrado" : "Nenhum documento cadastrado"}
                </TableCell>
              </TableRow>
            ) : (
              filteredDocuments?.map((doc) => (
                <TableRow key={doc.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-primary" />
                      <span className="font-medium text-foreground">{doc.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Link 
                      href={`/contador/clientes/${doc.clients?.id}`}
                      className="flex items-center gap-2 text-foreground hover:text-primary transition-colors"
                    >
                      <User className="w-4 h-4" />
                      <span>{doc.clients?.name}</span>
                    </Link>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary">{doc.category}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {formatDate(doc.created_at)}
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" asChild>
                      <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                        <Download className="w-4 h-4" />
                      </a>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
