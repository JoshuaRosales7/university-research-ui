import { createClient } from "@/lib/supabase/server"
import { ClienteDocumentsList } from "@/components/cliente/documents-list"

export default async function ClienteDocumentosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  // Get client record
  const { data: clientRecord } = await supabase
    .from("clients")
    .select("id")
    .eq("user_id", user!.id)
    .single()

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground">Meus Documentos</h1>
        <p className="text-muted-foreground mt-1">
          Visualize e baixe os documentos compartilhados pelo seu contador
        </p>
      </div>
      <ClienteDocumentsList clientId={clientRecord?.id || null} />
    </div>
  )
}
