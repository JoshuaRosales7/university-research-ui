import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Calendar, User } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function ClientePage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: userData } = await supabase
    .from("users")
    .select("name")
    .eq("id", user!.id)
    .single()

  // Get client record that matches this user's email
  const { data: clientRecord } = await supabase
    .from("clients")
    .select("id, contador_id")
    .eq("user_id", user!.id)
    .single()

  // Get document count
  const { count: docCount } = await supabase
    .from("documents")
    .select("*", { count: "exact", head: true })
    .eq("client_id", clientRecord?.id || "")

  // Get contador info if client is linked
  let contadorName = null
  if (clientRecord?.contador_id) {
    const { data: contadorData } = await supabase
      .from("users")
      .select("name")
      .eq("id", clientRecord.contador_id)
      .single()
    contadorName = contadorData?.name
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground">
          Bem-vindo, {userData?.name || "Cliente"}
        </h1>
        <p className="text-muted-foreground mt-1">
          Acompanhe seus documentos e informacoes
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Documentos
            </CardTitle>
            <FileText className="w-5 h-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{docCount || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">documentos disponíveis</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Seu Contador
            </CardTitle>
            <User className="w-5 h-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-semibold text-foreground">
              {contadorName || "Nao vinculado"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {contadorName ? "responsavel pela sua conta" : "aguardando vinculacao"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Status
            </CardTitle>
            <Calendar className="w-5 h-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-semibold text-foreground">Ativo</div>
            <p className="text-xs text-muted-foreground mt-1">conta em funcionamento</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Acesso Rapido</CardTitle>
          <CardDescription>Acesse suas funcionalidades principais</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <Button asChild variant="outline" className="justify-start h-auto py-4 bg-transparent">
            <Link href="/cliente/documentos">
              <FileText className="w-5 h-5 mr-3 text-primary" />
              <div className="text-left">
                <p className="font-medium text-foreground">Meus Documentos</p>
                <p className="text-sm text-muted-foreground">
                  Visualize e baixe seus documentos
                </p>
              </div>
            </Link>
          </Button>
          <Button asChild variant="outline" className="justify-start h-auto py-4 bg-transparent">
            <Link href="/cliente/configuracoes">
              <User className="w-5 h-5 mr-3 text-primary" />
              <div className="text-left">
                <p className="font-medium text-foreground">Configuracoes</p>
                <p className="text-sm text-muted-foreground">
                  Gerencie suas informacoes pessoais
                </p>
              </div>
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
