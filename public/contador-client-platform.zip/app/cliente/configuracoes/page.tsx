import { createClient } from "@/lib/supabase/server"
import { ClienteSettingsForm } from "@/components/cliente/settings-form"

export default async function ClienteConfiguracoesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: userData } = await supabase
    .from("users")
    .select("*")
    .eq("id", user!.id)
    .single()

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground">Configuracoes</h1>
        <p className="text-muted-foreground mt-1">
          Gerencie suas informacoes de conta
        </p>
      </div>
      <ClienteSettingsForm user={userData} />
    </div>
  )
}
