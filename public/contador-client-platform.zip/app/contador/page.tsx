import { createClient } from "@/lib/supabase/server"
import { ClientList } from "@/components/contador/client-list"

export default async function ContadorPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: userData } = await supabase
    .from("users")
    .select("name")
    .eq("id", user!.id)
    .single()

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground">
          Bem-vindo, {userData?.name || "Contador"}
        </h1>
        <p className="text-muted-foreground mt-1">
          Gerencie seus clientes e documentos
        </p>
      </div>
      <ClientList contadorId={user!.id} />
    </div>
  )
}
