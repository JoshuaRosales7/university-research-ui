import { createClient } from "@/lib/supabase/server"
import { SettingsForm } from "@/components/contador/settings-form"

export default async function ConfiguracoesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: userData } = await supabase
    .from("users")
    .select("*")
    .eq("id", user!.id)
    .single()

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground">Configuracoes</h1>
        <p className="text-muted-foreground mt-1">
          Gerencie suas informacoes de conta
        </p>
      </div>
      <SettingsForm user={userData} />
    </div>
  )
}
