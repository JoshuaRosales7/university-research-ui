import { createClient } from "@/lib/supabase/server"
import { AllDocumentsList } from "@/components/contador/all-documents-list"

export default async function DocumentosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground">Documentos</h1>
        <p className="text-muted-foreground mt-1">
          Todos os documentos de seus clientes
        </p>
      </div>
      <AllDocumentsList contadorId={user!.id} />
    </div>
  )
}
