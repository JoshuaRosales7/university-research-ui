import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calculator, AlertCircle } from "lucide-react"

export default function AuthErrorPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader>
          <div className="flex justify-center mb-4">
            <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-destructive/10 text-destructive">
              <AlertCircle className="w-7 h-7" />
            </div>
          </div>
          <CardTitle className="text-2xl font-semibold text-foreground">Erro de autenticacao</CardTitle>
          <CardDescription className="text-muted-foreground">
            Ocorreu um erro ao processar sua solicitacao
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <p className="text-sm text-muted-foreground">
            Por favor, tente novamente ou entre em contato com o suporte se o problema persistir.
          </p>
          <Button asChild className="mt-2">
            <Link href="/auth/login">Voltar para o login</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
