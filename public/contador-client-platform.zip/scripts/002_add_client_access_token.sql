-- Add access token to clients table for direct access without login
ALTER TABLE public.clients
ADD COLUMN IF NOT EXISTS access_token UUID DEFAULT gen_random_uuid() UNIQUE;

-- Create index for faster token lookups
CREATE INDEX IF NOT EXISTS idx_clients_access_token ON public.clients(access_token);

-- RLS policy to allow public access via token (for client portal)
CREATE POLICY "public_access_via_token" ON public.clients
  FOR SELECT USING (true);

-- Documents accessible via client token
CREATE POLICY "public_view_documents_via_token" ON public.documents
  FOR SELECT USING (true);
