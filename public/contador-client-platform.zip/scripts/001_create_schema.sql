-- ContaApp Database Schema
-- This script creates all tables and RLS policies for the accounting client management platform

-- Users table (extends auth.users)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('admin', 'client')) DEFAULT 'client',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Clients table
CREATE TABLE IF NOT EXISTS public.clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  nit TEXT NOT NULL UNIQUE,
  email TEXT,
  phone TEXT,
  contributor_type TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Documents table
CREATE TABLE IF NOT EXISTS public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  fiscal_year INTEGER NOT NULL,
  file_path TEXT NOT NULL,
  uploaded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notes table (internal notes for contador only)
CREATE TABLE IF NOT EXISTS public.notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security on all tables
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

-- Helper function to check if user is admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- Helper function to get client_id for current user
CREATE OR REPLACE FUNCTION public.get_user_client_id()
RETURNS UUID
LANGUAGE SQL
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.clients WHERE user_id = auth.uid() LIMIT 1;
$$;

-- =====================
-- RLS POLICIES FOR USERS
-- =====================

-- Admin can see all users
CREATE POLICY "admin_view_all_users" ON public.users
  FOR SELECT USING (public.is_admin());

-- Users can see their own record
CREATE POLICY "users_view_own" ON public.users
  FOR SELECT USING (auth.uid() = id);

-- Admin can insert users
CREATE POLICY "admin_insert_users" ON public.users
  FOR INSERT WITH CHECK (public.is_admin() OR auth.uid() = id);

-- Admin can update any user
CREATE POLICY "admin_update_users" ON public.users
  FOR UPDATE USING (public.is_admin());

-- Users can update their own record
CREATE POLICY "users_update_own" ON public.users
  FOR UPDATE USING (auth.uid() = id);

-- =====================
-- RLS POLICIES FOR CLIENTS
-- =====================

-- Admin can view all clients
CREATE POLICY "admin_view_all_clients" ON public.clients
  FOR SELECT USING (public.is_admin());

-- Clients can view their own profile
CREATE POLICY "clients_view_own" ON public.clients
  FOR SELECT USING (user_id = auth.uid());

-- Admin can insert clients
CREATE POLICY "admin_insert_clients" ON public.clients
  FOR INSERT WITH CHECK (public.is_admin());

-- Admin can update clients
CREATE POLICY "admin_update_clients" ON public.clients
  FOR UPDATE USING (public.is_admin());

-- Admin can delete clients
CREATE POLICY "admin_delete_clients" ON public.clients
  FOR DELETE USING (public.is_admin());

-- =====================
-- RLS POLICIES FOR DOCUMENTS
-- =====================

-- Admin can view all documents
CREATE POLICY "admin_view_all_documents" ON public.documents
  FOR SELECT USING (public.is_admin());

-- Clients can view their own documents
CREATE POLICY "clients_view_own_documents" ON public.documents
  FOR SELECT USING (
    client_id IN (SELECT id FROM public.clients WHERE user_id = auth.uid())
  );

-- Admin can insert documents for any client
CREATE POLICY "admin_insert_documents" ON public.documents
  FOR INSERT WITH CHECK (public.is_admin());

-- Clients can insert documents for themselves
CREATE POLICY "clients_insert_own_documents" ON public.documents
  FOR INSERT WITH CHECK (
    client_id IN (SELECT id FROM public.clients WHERE user_id = auth.uid())
  );

-- Admin can update any document
CREATE POLICY "admin_update_documents" ON public.documents
  FOR UPDATE USING (public.is_admin());

-- Admin can delete any document
CREATE POLICY "admin_delete_documents" ON public.documents
  FOR DELETE USING (public.is_admin());

-- =====================
-- RLS POLICIES FOR NOTES
-- =====================

-- Only admin can view notes
CREATE POLICY "admin_view_notes" ON public.notes
  FOR SELECT USING (public.is_admin());

-- Only admin can insert notes
CREATE POLICY "admin_insert_notes" ON public.notes
  FOR INSERT WITH CHECK (public.is_admin());

-- Only admin can update notes
CREATE POLICY "admin_update_notes" ON public.notes
  FOR UPDATE USING (public.is_admin());

-- Only admin can delete notes
CREATE POLICY "admin_delete_notes" ON public.notes
  FOR DELETE USING (public.is_admin());

-- =====================
-- TRIGGER FOR AUTO-CREATE USER PROFILE
-- =====================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.users (id, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'role', 'client')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- =====================
-- STORAGE BUCKET FOR DOCUMENTS
-- =====================

-- Create storage bucket for documents (private)
INSERT INTO storage.buckets (id, name, public)
VALUES ('documents', 'documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for documents bucket
CREATE POLICY "admin_access_all_files" ON storage.objects
  FOR ALL USING (
    bucket_id = 'documents' AND public.is_admin()
  );

CREATE POLICY "clients_view_own_files" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'documents' AND
    (storage.foldername(name))[1] IN (
      SELECT id::text FROM public.clients WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "clients_upload_own_files" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'documents' AND
    (storage.foldername(name))[1] IN (
      SELECT id::text FROM public.clients WHERE user_id = auth.uid()
    )
  );
